# Entrega da parte estatística - versão 3.4

Este diretório contém a contribuição ao Item 3 (análise estatística e exploratória) do trabalho “A queda nacional da morosidade alcançou todos os estados?”. O PDF é a seção estatística para integração ao relatório final do grupo, cujo limite total é de 7 a 9 páginas.

O arquivo `relatorio_item3.md` é a fonte textual editável do relatório. As figuras referenciadas ficam em `figuras/`. O arquivo `queda_nacional_morosidade_v3_4.ipynb` corresponde ao notebook principal revisado; a base utilizada é `base_davi_lemes_ferreira_reduzida.csv`.

Para reproduzir as duas figuras do relatório, execute `python gerar_figuras_item3.py` após instalar as dependências. Os cálculos completos e as verificações de sensibilidade permanecem no notebook.

## Execução

Mantenha o notebook e o CSV no mesmo diretório. No Google Colab, envie ambos e execute as células em ordem. Em um ambiente Python local, instale as dependências com `python -m pip install -r requirements.txt` e abra o notebook em um editor compatível com Jupyter. O arquivo de dependências registra as versões do ambiente de validação; Python 3.13 foi utilizado nesta revisão.

O notebook completo mantém a análise exploratória, incluindo distribuições, outliers e verificações de sensibilidade. O relatório seleciona os resultados centrais. As 292 observações se repetem por tribunal ao longo do tempo; os coeficientes são descritivos e não demonstram causalidade. A comparação uniforme de 2019 a 2025 é complementar à série histórica completa, e a faixa de estabilidade de ±10% é uma convenção analítica do grupo.

Repositório do grupo: https://github.com/rlcardim/fundamentos-trabalho1

Preparado em 31/10/2026. Os arquivos foram preparados para revisão e commit pelo usuário; não houve publicação ou envio ao GitHub.
