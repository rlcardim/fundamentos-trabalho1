# 3. Análise estatística e exploratória

A queda nacional da morosidade alcançou todos os estados?

**Contribuição para integração ao relatório do grupo - versão 3.4, 31/10/2026.**

Neste trabalho, avaliamos se a redução do tempo até a baixa dos processos de conhecimento não criminais no primeiro grau ocorreu de forma semelhante nos Tribunais de Justiça. Utilizamos a base reduzida do grupo, com 292 registros de 27 tribunais, incluindo o TJDFT, entre 2015 e 2025. Cada registro corresponde a um tribunal em um ano. A base contém informações de 23 tribunais em 2015, 26 em 2017 e 27 nos demais anos.

Calculamos a média, a mediana, o desvio-padrão, a amplitude interquartílica e o coeficiente de variação. Examinamos a evolução anual do indicador e comparamos as mudanças de cada tribunal. Para avaliar as associações com as demais variáveis, calculamos a correlação de Pearson e repetimos o cálculo retirando um tribunal por vez. Essas análises descrevem os dados e não permitem estabelecer relações de causa e efeito.

## 3.1 Evolução do nível e da dispersão

**Tabela 1. Medidas do tempo até a baixa por ano de referência.**

| Medida | 2015 | 2019 | 2025 |
|---|---|---|---|
| Tribunais observados | 23 | 27 | 27 |
| Média (dias) | 987,91 | 1.081,70 | 670,80 |
| Mediana (dias) | 1.002,00 | 1.054,00 | 654,74 |
| Desvio-padrão (dias) | 416,34 | 507,48 | 253,23 |
| Amplitude interquartílica (dias) | 617,00 | 524,00 | 234,71 |
| Coeficiente de variação | 42,14% | 46,91% | 37,75% |

![Figura 1. Evolução da mediana dos tribunais.](figuras/mediana_anual.png)

A mediana diminuiu de 1.002,00 dias em 2015 para 654,74 dias em 2025. Essa redução não ocorreu de maneira contínua. O indicador apresentou oscilações, alcançou 1.054,00 dias em 2019 e caiu de forma acentuada em 2020. Entre 2019 e 2025, o desvio-padrão diminuiu de 507,48 para 253,23 dias, e a amplitude interquartílica passou de 524,00 para 234,71 dias. O coeficiente de variação também diminuiu, de 46,91% para 37,75%, embora tenha apresentado aumentos em alguns anos intermediários.

Cada tribunal participa do cálculo da mediana com o mesmo peso. Portanto, essa medida não representa uma média nacional ponderada pelo número de processos. A comparação com 2015 também exige considerar que aquele ano reúne menos tribunais.

## 3.2 Diferenças entre tribunais

Comparamos os anos de 2019 e 2025 porque ambos apresentam registros dos mesmos 27 tribunais. O grupo adotou redução superior a 10%, aumento superior a 10% e estabilidade no intervalo entre esses limites, incluindo os valores de -10% e +10%. Esses limites constituem uma convenção para descrever as variações. Nessa comparação, 24 tribunais apresentaram redução superior a 10% e três ficaram na faixa de estabilidade. Nenhum apresentou aumento superior a 10%.

![Figura 2. Variação do tempo até a baixa, 2019-2025.](figuras/variacao_2019_2025.png)

A classificação como estável não significa que o indicador permaneceu inalterado. O TJRS apresentou redução de 3,51%. O TJAC e o TJDFT, por sua vez, registraram aumentos de 1,71% e 8,44%. Assim, 25 tribunais apresentaram alguma redução entre 2019 e 2025, enquanto dois tiveram aumento. A redução do tempo até a baixa foi ampla, mas não alcançou todos os tribunais nesse período.

O período escolhido modifica a classificação de alguns tribunais. Quando comparamos o primeiro e o último registro disponível de cada um, encontramos 22 tribunais com redução superior a 10% e cinco na faixa de estabilidade. Seis tribunais mudaram de categoria na comparação de 2019 com 2025. Como 2019 apresentou valores elevados, mantivemos essa comparação como complemento à série histórica. Ela não substitui a análise da evolução desde 2015.

## 3.3 Correlações exploratórias

**Tabela 2. Correlações com o tempo até a baixa, 292 registros tribunal-ano.**

| Variável | Pearson (r) |
|---|---|
| Força de trabalho por 100 mil habitantes | -0,548 |
| Logaritmo da população | 0,528 |
| Despesa relativa por processo | -0,527 |
| Carga por servidor | 0,515 |
| Estoque por magistrado | 0,515 |
| Litigiosidade | -0,422 |
| Densidade demográfica | 0,052 |
| Afastamento por magistrado | -0,020 |

O estoque por magistrado apresentou correlação positiva com o tempo até a baixa (r = 0,515). Nos registros analisados, estoques maiores tendem a aparecer acompanhados de tempos maiores. A força de trabalho por 100 mil habitantes apresentou correlação negativa (r = -0,548), enquanto o logaritmo da população apresentou correlação positiva (r = 0,528). Esses resultados indicam associações, mas não demonstram que a alteração de uma dessas variáveis provoque mudança no tempo até a baixa.

Verificamos também quanto a correlação do estoque depende dos registros do TJRJ. Ao retirar os 11 registros desse tribunal, o coeficiente de Pearson diminui de 0,515 para 0,331. A associação permanece positiva, mas sua intensidade diminui. Esse resultado mostra que a presença de um tribunal pode modificar de forma relevante o coeficiente calculado para o conjunto.

A despesa relativa por processo apresentou correlação negativa com o tempo até a baixa (r = -0,527). O total de processos aparece no denominador dessa variável e no numerador da carga por servidor. Essa forma de cálculo pode contribuir para a associação entre os dois indicadores de despesa e carga. Portanto, a correlação com o tempo não permite concluir que um gasto maior produziria maior rapidez. A densidade demográfica e o afastamento por magistrado apresentaram coeficientes próximos de zero no conjunto analisado, o que indica pouca associação linear nesse cálculo e não exclui outras relações.

## 3.4 Limites da análise e resposta ao problema

A base reúne registros anuais dos mesmos tribunais. Por essa razão, não consideramos as 292 observações como independentes. As correlações podem refletir tanto diferenças entre tribunais quanto mudanças dentro de cada tribunal ao longo do tempo. Não separamos essas duas situações nesta análise. Além disso, o indicador considera os processos baixados em cada ano. Ele não representa o tempo de espera de todos os processos em tramitação, e os resultados por tribunal não podem ser atribuídos automaticamente a cada vara, processo ou cidadão.

Os resultados mostram redução do tempo até a baixa e da dispersão entre tribunais nas comparações realizadas. Entretanto, os tribunais apresentaram trajetórias diferentes e mantiveram diferenças relevantes ao final do período. Na comparação entre 2019 e 2025, a maioria reduziu o indicador, mas dois tribunais apresentaram aumento. Podemos, portanto, afirmar que houve uma redução ampla, sem concluir que todos os tribunais ou todos os jurisdicionados tiveram a mesma melhora. Os dados utilizados não permitem identificar as causas dessas mudanças.

**Fonte das tabelas e figuras:** Base reduzida fornecida pelo grupo; cálculos próprios reproduzíveis no notebook, versão 3.4.
