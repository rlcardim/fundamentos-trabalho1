"""Reproduz as duas figuras selecionadas para o Item 3 do relatório."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


def main():
    pasta = Path(__file__).resolve().parent
    figuras = pasta / "figuras"
    figuras.mkdir(exist_ok=True)
    df = pd.read_csv(
        pasta / "base_davi_lemes_ferreira_reduzida.csv", sep=";", decimal=","
    ).rename(columns={"tpbaixcncrim1m": "tempo_baixa"})
    assert not df.duplicated(["sigla", "ano"]).any()

    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 10,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.titleweight": "bold",
    })
    azul = "#205b79"
    mediana = df.groupby("ano")["tempo_baixa"].median()
    fig, ax = plt.subplots(figsize=(7.4, 3.4))
    ax.plot(mediana.index, mediana, color=azul, marker="o", markersize=4, linewidth=2)
    ax.set(xlabel="Ano", ylabel="Mediana do tempo até a baixa (dias)",
           title="Evolução da mediana entre os tribunais")
    ax.set_xticks(mediana.index)
    ax.tick_params(axis="x", labelsize=8)
    ax.grid(axis="y", alpha=.2)
    fig.tight_layout()
    fig.savefig(figuras / "mediana_anual.png", dpi=220, facecolor="white")
    plt.close(fig)

    inicial = df.loc[df["ano"] == 2019].set_index("sigla")["tempo_baixa"]
    final = df.loc[df["ano"] == 2025].set_index("sigla")["tempo_baixa"]
    assert inicial.index.nunique() == final.index.nunique() == 27
    assert set(inicial.index) == set(final.index)
    variacao = ((final - inicial) / inicial * 100).sort_values()
    cores = [azul if valor < -10 else "#8b8d8f" for valor in variacao]
    fig, ax = plt.subplots(figsize=(7.4, 5.7))
    ax.barh(variacao.index, variacao.values, color=cores, height=.72)
    ax.invert_yaxis()
    ax.axvline(0, color="#333", linewidth=.9)
    for limite in [-10, 10]:
        ax.axvline(limite, color="#aaa", linewidth=.8, linestyle="--")
    for i, valor in enumerate(variacao):
        ax.text(valor - .9 if valor < 0 else valor + .9, i,
                f"{valor:.1f}%".replace(".", ","),
                ha="right" if valor < 0 else "left", va="center", fontsize=8)
    ax.set_xlim(-67, 18)
    ax.set(xlabel="Variação do tempo até a baixa (%)",
           title="Variação por tribunal: 2019 a 2025")
    ax.tick_params(axis="both", labelsize=8)
    ax.grid(axis="x", alpha=.15)
    ax.set_axisbelow(True)
    fig.tight_layout()
    fig.savefig(figuras / "variacao_2019_2025.png", dpi=220, facecolor="white")
    plt.close(fig)
    print("Figuras atualizadas em:", figuras)


if __name__ == "__main__":
    main()
